# 1.0.3
- Fixed issues related to not checking if objects exist resulting in buggy gameplay
  
# 1.0.0
- release
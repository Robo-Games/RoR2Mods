# 1.1.0
- Fixed some bugs, added support for sticky bombs and ghors tome
  
# 1.0.3
- Fixed issues related to not checking if objects exist resulting in buggy gameplay
  
# 1.0.0
- release
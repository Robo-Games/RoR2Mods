# Uncapped Chances
Allows stacking chance items to roll multiple times past 100%. Currently supports crit, bleed and collapse. 

Provides option to toggle on or off each of the effects in the config file.

Each effect can additionally have a "Lower Successive" option turned on, meaning for each succesive roll of the effect, the chance is lowered. ie, for the second crit, crit chance is half as effective, for the third crit its 1/3rd as effective, and so on. By default this option is off.

There is an option for if crit damage is to stack up multiplicatively or additively, ie, 2>4>6 or 2>4>8.